# q2-picrust2
QIIME 2 plugin for PICRUSt2

For descriptions of how to install and run this plugin, see [here](https://github.com/picrust/picrust2/wiki/q2-picrust2-Tutorial/).
